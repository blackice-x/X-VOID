
---

# 🔐 Security Policy

## 📦 Supported Versions

Below are the versions currently maintained with security updates:

| Version | Status              |
| ------- | ------------------- |
| 5.1.x   | ✅ Supported         |
| 5.0.x   | ❌ Not Supported     |
| 4.0.x   | ✅ Supported         |
| < 4.0   | ❌ Not Supported     |

## 🛡️ Reporting Vulnerabilities

If you discover a vulnerability in **X-VOID**, please follow these steps:

- Report it **privately** via our [Support Server](https://discord.gg/8naFJKGGCv)
- Include details like version number, reproduction steps, and severity
- Please do **not disclose** vulnerabilities publicly before we confirm and fix them

### Response Expectations

- Acknowledgement within **48 hours**
- Progress updates every **3–5 business days**
- Fixes released based on severity (critical within 72 hours)

We appreciate your help in keeping **X-VOID** safe and secure for all users.

---
