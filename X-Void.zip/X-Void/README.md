Sure! Here's a **shortened and updated version** of your Lanya Discord Bot README with **branding changed to "X-VOID"** and all Discord links replaced with `https://discord.gg/8naFJKGGCv`:

---

<div align="center">

  <h1><img src="utils/logo.jpg" alt="X-VOID Logo" width="35"> X-VOID Discord Bot</h1>
  <br>
  <p><strong>An open-source multipurpose bot to power up your Discord server with smart features & seamless interaction.</strong></p>

  [![Discord](https://img.shields.io/discord/865198018872999966?color=5865F2&logo=discord&logoColor=white)](https://discord.gg/8naFJKGGCv)
  [![License](https://img.shields.io/github/license/birajrai/Lanya)](LICENSE)
  [![Stars](https://img.shields.io/github/stars/birajrai/Lanya?style=social)](https://github.com/birajrai/Lanya/stargazers)

</div>

## ✨ About X-VOID

X-VOID is your go-to bot for everything from moderation to Minecraft stats. Packed with useful tools, games, giveaways, and more—it's built to engage and empower your community.

## 🚀 Features

- 🎉 **Fun** – Memes, trivia, jokes, 8-ball & more  
- 🛠️ **Moderation** – Ban, kick, lock, timeout, warn  
- 🧩 **Utilities** – Calculator, weather, translator  
- 🎮 **Minecraft** – Skins, avatars, server status  
- 📈 **Leveling** – XP-based ranks and leaderboards  
- 🎁 **Giveaways** – Fully configurable reward events  
- 👋 **Welcome** – Custom greetings for new members

## 🧾 Commands

### ℹ️ Info  
`/botinfo`, `/help`, `/ping`, `/userinfo`, `/serverinfo`, `/invite`, `/support`

### 🎈 Fun  
`/8ball`, `/meme`, `/joke`, `/pp`, `/catfact`, `/trivia`, `/coinflip`, etc.

### 🔨 Moderation  
`/ban`, `/kick`, `/warn`, `/timeout`, `/clear`, `/lock`, `/unban`, `/untimeout`

### 🛠️ Utilities  
`/calculator`, `/define`, `/translate`, `/weather`, `/todo`

### ⚙️ Admin  
`/giveaway`, `/leveladmin`, `/welcome`, `/autorole`, `/guildsettings`

### 🌍 Minecraft  
`/skin`, `/serverstatus`, `/addserverstatus`, `/headavatar`, `/achievement`, etc.

### 📊 Leveling  
`/level`, `/leaderboard`

## ⚡ Quick Setup

### Requirements
- Node.js v16.9+
- MongoDB
- Discord Bot Token
- Weather API Key

### Installation

```bash
git clone https://github.com/birajrai/Lanya.git
cd Lanya
npm install
npm run start
```

Fill in your token, MongoDB URI, and API keys in the setup prompts.

## 🗂️ Structure

```
X-VOID/
├── commands/
├── events/
├── models/
├── utils/
├── config.json
├── index.js
└── setup.js
```

## 🧪 Add a Command

```js
module.exports = {
  name: 'commandname',
  description: 'What it does',
  options: [],
  execute: async (interaction, client) => {
    // logic here
  },
};
```

## 🤝 Contribute

1. Fork & clone  
2. `git checkout -b feature/new-feature`  
3. Commit & push  
4. Open a PR 🚀

## 📜 Conduct

- Be kind and respectful  
- Stay inclusive  
- Help others  

## 📋 Roadmap

- [ ] Server logs  
- [ ] Auto-moderation  
- [ ] Custom command builder  
- [ ] Web dashboard  
- [ ] Music playback  
- [ ] Reaction roles  

Got ideas? [Join Our Support Server](https://discord.gg/8naFJKGGCv)

---

<div align="center">
  Built with ❤️ by the X-VOID Dev Team
</div>

---
