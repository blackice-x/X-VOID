
---

# 📜 Terms of Service  
_Last updated: April 17, 2025_

Welcome to **X-VOID**! By using the bot (“the Bot”), you agree to the following terms. If you do not accept them, please stop using the Bot.

## 1. Usage

- **X-VOID** is free and open-source under the [MIT License](LICENSE).
- You must follow [Discord’s Terms of Service](https://discord.com/terms).
- Do not use the Bot for harmful, abusive, or illegal activities.

## 2. Availability

- The Bot is provided “as is” with no guarantees of uptime or continued support.
- Features and services may change or be removed without notice.

## 3. Liability

- The developers are not responsible for any loss, damage, or misuse resulting from the use of X-VOID.
- Use the Bot at your own risk.

## 4. Changes to Terms

- These terms may be updated at any time.
- Continued use after changes means you accept the new terms.

Need help or have questions? Join our [Support Server](https://discord.gg/8naFJKGGCv).

---
